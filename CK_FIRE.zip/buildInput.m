function data = buildInput(Xstr, Ystr, fstr, h)
% Xstr, Ystr: chuỗi nhập từ EditField
% fstr: chuỗi hàm
% h: bước

    if ~isempty(Xstr) && ~isempty(Ystr)
        X = str2num(Xstr); %#ok
        Y = str2num(Ystr);

        if length(X) ~= length(Y)
            error('X và Y phải cùng kích thước');
        end

        data.type = 'table';
        data.X = X;
        data.Y = Y;

    elseif ~isempty(fstr)
        syms x
        f = str2sym(fstr);

        data.type = 'function';
        data.f = matlabFunction(f);
        data.h = h;

    else
        error('Chưa nhập dữ liệu đầu vào');
    end
end
