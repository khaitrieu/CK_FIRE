function kq = solveDerivative(data, x0, method, order)

    if strcmp(data.type,'function')
        kq = finiteDiff(data.f, x0, data.h, method, order);

    else
        X = data.X;
        Y = data.Y;
        h = X(2)-X(1);

        idx = find(X==x0,1);
        if isempty(idx)
            error('x0 không tồn tại trong X');
        end

        switch method
            case 'tien'
                kq = (Y(idx+1)-Y(idx))/h;
            case 'lui'
                kq = (Y(idx)-Y(idx-1))/h;
            case 'trungtam'
                kq = (Y(idx+1)-Y(idx-1))/(2*h);
        end
    end
end
