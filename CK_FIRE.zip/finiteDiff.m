function df = finiteDiff(f, x0, h, method, order)

    switch method
        case 'tien'
            if order == 1
                df = (f(x0+h)-f(x0))/h;
            else
                df = (-3*f(x0)+4*f(x0+h)-f(x0+2*h))/(2*h);
            end

        case 'lui'
            if order == 1
                df = (f(x0)-f(x0-h))/h;
            else
                df = (3*f(x0)-4*f(x0-h)+f(x0-2*h))/(2*h);
            end

        case 'trungtam'
            df = (f(x0+h)-f(x0-h))/(2*h);
    end
end
